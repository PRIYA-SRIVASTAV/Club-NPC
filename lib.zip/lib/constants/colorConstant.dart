import 'package:flutter/material.dart';

Color appThemeColor =  const Color.fromRGBO(33,35,100,1);