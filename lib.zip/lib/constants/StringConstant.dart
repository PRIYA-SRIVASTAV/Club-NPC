String appTitle = "WELCOME TO NPC PORTAL";
String appSubTitle = "VOICE OF CONSTRUCTION INDUSTRY";
String registerToNpc = "REGISTER TO NPC PORTAL";
String skip = "Skip";
String dashboard = "Dashboard";
String workOrders = "Work Orders";

//On boarding page content
//on Boarding first page.
String title1 = "Is machine breakdown situation \n    keeping you awake at night?";
String title2 = "India's first digital machine \n      servicing platform.";

//on Boarding Second page.
String title3 = "   Do you find it difficult to get\nengineers when your machine \n                   is down?";
String title4 = "Use our App and get instant \nsupport of skillful engineers,\n          online and onsite.";

//on Boarding Third page.
String title5 = "Is it challenging to get the right \n   spares at reasonable cost?";
String title6 = "Use our digital Market Place \nfor prompt supply of quality \n                      parts.";

//on Boarding Fourth page.
String title7 ="     Does it take too long to \ndiagnose the root cause of the \n                   problem?";
String title8 = "Take help of our Digital tool \nand expert panel for timely \n                resolution.";
